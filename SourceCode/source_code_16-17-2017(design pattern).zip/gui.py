from flask import Flask
from flask import request
from flask import render_template
import linear_learner
app = Flask(__name__)


def analyse_stock(learner, ticker, options):
    confidence_score = learner.analyse(ticker, options)
    return confidence_score


@app.route('/')
def my_form():
    return render_template('index.html')


@app.route('/', methods=['POST'])
def my_form_post():
    if request.method == 'POST':
        options = []
        ticker = request.form['ticker']
        chosen_learner = request.form.get('chosen_learner')

        if request.form.get('10ma'):
            options.append('10ma')
        if request.form.get('100ma'):
            options.append('100ma')
        if request.form.get('250ma'):
            options.append('250ma')

        if str(chosen_learner) == 'linear_learner':
            confidence_score = analyse_stock(linear_learner, ticker, options)
            return "Confidence Score of Linear Regression Analysis: " + str(confidence_score)
        else:
            return "die"
        # return render_template("result.html", result=result)

if __name__ == '__main__':
    app.run()