from flask import Flask
from flask import request
from flask import render_template
import bokeh_LR_test

app = Flask(__name__)

@app.route('/')
def my_form():
    return render_template('index.html')

@app.route('/', methods=['POST'])
def my_form_post():
    if request.method == 'POST':
        result = request.form['ticker']
        confidence_score = bokeh_LR_test.query_ticker(result)
        return "Confidence Score of Linear Regression Analysis: " + str(confidence_score)
        # return render_template("result.html", result=result)

if __name__ == '__main__':
    app.run()