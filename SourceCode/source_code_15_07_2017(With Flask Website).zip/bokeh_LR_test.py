import numpy as np

from bokeh.layouts import gridplot
from bokeh.plotting import figure, show, output_file
import quandl
import ml_LR

# Quandl requires API key to fetch the stock data
# quandl.ApiConfig.api_key = '4_oX5z6kBUsPsQgkZgXn'

def datetime(x):
    return np.array(x, dtype=np.datetime64)


def query_ticker(ticker):
    # GOOGL = quandl.get("WIKI/GOOGL", returns="pandas", start_date="2017-06-01", end_date="2017-07-14")
    original, trained_TICKER, confidence_score = ml_LR.LR_training(ticker)

    # Change the index from date to number which start from 0 to the length of rows of stock
    trained_TICKER['Date'] = trained_TICKER.index
    trained_TICKER.index = range(len(trained_TICKER))

    original['Date'] = original.index
    original.index = range(len(original))

    # Boket plot setting
    p1 = figure(x_axis_type="datetime", title="Stock Closing Prices")
    p1.grid.grid_line_alpha=0.3
    p1.xaxis.axis_label = 'Date'
    p1.yaxis.axis_label = 'Price'

    # Draw line
    p1.line(datetime(trained_TICKER['Date']), trained_TICKER['Adj. Close'], color='#A6CEE3', legend=ticker)
    p1.line(datetime(trained_TICKER['Date']), trained_TICKER['Forecast'], color='#B2DF8A', legend='Forecast')
    p1.line(datetime(original['Date']), original['Adj. Close'], color='#33A02C', legend='Original')

    p1.legend.location = 'top_left'

    # googl = np.array(GOOGL['Close'])
    # googl_dates = np.array(GOOGL['Date'], dtype=np.datetime64)

    # window_size = 30
    # window = np.ones(window_size)/float(window_size)
    # googl_avg = np.convolve(googl, window, 'same')

    output_file("stocks.html", title="stocks.py example")

    show(gridplot([[p1]], plot_width=400, plot_height=400))  # open a browser
    return confidence_score