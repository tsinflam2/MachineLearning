import plotly

py = plotly.plotly('JohnnyLam','T4JhRZWvDWXlqWl0EXxv')

a = (1, 2, 3, 4 ,5)
b = (2, 3, 5, 6, 1)

py.plot(a,b)